#pragma once

#include <Windows.h>
#include <stdio.h>
#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif
namespace DLLInject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/*
	 *TODO: the following initial values do not work! Change these and include comments!
	 * MOVED TO PROCESS INPUT
	 */
	boolean rapidFire;
	/// <summary>
	/// Summary for StatusWindow
	/// </summary>
	public ref class StatusWindow : public System::Windows::Forms::Form
	{
	public:
		StatusWindow(void)
		{
			InitializeComponent();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~StatusWindow()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ submitButton;
	protected:
	private: System::Windows::Forms::TextBox^ inputTextBox;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->submitButton = (gcnew System::Windows::Forms::Button());
			this->inputTextBox = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// submitButton
			// 
			this->submitButton->Location = System::Drawing::Point(118, 95);
			this->submitButton->Name = L"submitButton";
			this->submitButton->Size = System::Drawing::Size(163, 41);
			this->submitButton->TabIndex = 0;
			this->submitButton->Text = L"Submit";
			this->submitButton->UseVisualStyleBackColor = true;
			this->submitButton->Click += gcnew System::EventHandler(this, &StatusWindow::submitButton_Click);
			// 
			// inputTextBox
			// 
			this->inputTextBox->Location = System::Drawing::Point(36, 36);
			this->inputTextBox->Name = L"inputTextBox";
			this->inputTextBox->Size = System::Drawing::Size(337, 20);
			this->inputTextBox->TabIndex = 1;
			this->inputTextBox->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &StatusWindow::inputTextBox_KeyDown);
			// 
			// StatusWindow
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(401, 148);
			this->Controls->Add(this->inputTextBox);
			this->Controls->Add(this->submitButton);
			this->Name = L"StatusWindow";
			this->Text = L"CommandWindow";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void inputTextBox_KeyDown(System::Object^ sender, System::Windows::Forms::KeyEventArgs^ e) {
		if (e->KeyCode == Keys::Enter)
		{
			processInput();
		}

	}

	private: System::Void submitButton_Click(System::Object^ sender, System::EventArgs^ e) {
		processInput();
	}

	private: System::Void processInput() {
		String^ input = inputTextBox->Text;//user input
		inputTextBox->Text = "";

		//Task 2 - Unlimited Ammo
		char cheat_myCheat_Instr[7] = { '\x90', '\x90' ,'\x90', '\x90' ,'\x90' ,'\x90','\x90' };//remove the subtraction
		char original_myCheat_Instr[7] = { '\x29', '\x8C' ,'\x90', '\xA4' ,'\x00' ,'\x00','\x00' };//original code
		int num_myCheat_InstrBytes = sizeof(original_myCheat_Instr);//size of the cheat
		DWORD myCheat_InstrAddress = 0x0043D971;//address of the original 
		if (String::Compare(input, "ammo cheat on", true) == 0)//enable infinite ammo cheat
			overwriteMemory(myCheat_InstrAddress, cheat_myCheat_Instr, num_myCheat_InstrBytes);
		else if (String::Compare(input, "ammo cheat off", true) == 0)//disable infinite ammo cheat
			overwriteMemory(myCheat_InstrAddress, original_myCheat_Instr, num_myCheat_InstrBytes);

		//Task 3 - Set Ammo
		//split the input to obtain the value the user wants to set the ammo
		array<String^>^ SplitInput = input->Split(' ');//ammot set 50
		//puts back ammo + set with space in between
		String^ inputToCheck = SplitInput[0] + " " + SplitInput[1];//used for the input
		if (String::Compare(inputToCheck, "ammo set", true) == 0) {//cheat used to set ammo
			myCheat_InstrAddress = 0x0050D24C;//get ammo address
			char new_cheat[1] = { System::Convert::ToByte(SplitInput[2]) };//convert input into bytes
			overwriteMemory(myCheat_InstrAddress, new_cheat, sizeof(new_cheat));//overwrite ammo value
		}

		//Task 4 - Health Cheat
		if (String::Compare(input, "health cheat on", true) == 0) {
			//00430AE5
			//00430AEA
			DWORD myCheat_InstrAddressRealHealth = 0x00430AE5;//Real Health part1
			DWORD myCheat_InstrAddressRealHealth2 = 0x00430AEA;//Real Health part2
			DWORD myCheat_InstrAddressVisualHealth = 0x00430A95;//Visual Health
			char nop[2] = { '\x90','\x90' };//nop for 2 bytes
			overwriteMemory(myCheat_InstrAddressVisualHealth, nop, sizeof(nop));//make sure visual health never decreases
			overwriteMemory(myCheat_InstrAddressRealHealth, nop, sizeof(nop));//make sure realth health never decreases
			overwriteMemory(myCheat_InstrAddressRealHealth2, nop, sizeof(nop));//make sure realth health never decreases
		}
		else if (String::Compare(input, "health cheat off", true) == 0) {
			DWORD myCheat_InstrAddressRealHealth = 0x00430AE5;//Real Health part1
			DWORD myCheat_InstrAddressRealHealth2 = 0x00430AEA;//Real Health part2
			DWORD myCheat_InstrAddressVisualHealth = 0x00430A95;//Visual Health
			char restoreVHealth[2] = { '\x29','\xD8' };//restore visual health sub eax,ebx
			char restoreRHealth[2] = { '\x85','\xC0' };//restore real health - test eax,eax
			char restoreRHealth2[2] = { '\x29','\xD8' };//restore real health - sub eax,ebx
			overwriteMemory(myCheat_InstrAddressVisualHealth, restoreVHealth, sizeof(restoreVHealth));//make sure visual health never decreases
			overwriteMemory(myCheat_InstrAddressRealHealth, restoreRHealth, sizeof(restoreRHealth));//make sure realth health never decreases
			overwriteMemory(myCheat_InstrAddressRealHealth2, restoreRHealth2, sizeof(restoreRHealth2));//make sure realth health never decreases
		}

		//Task 5 - oneshot-onekill
		if (String::Compare(input, "one-shot on", true) == 0) {
			boolean injectionCreated = false;
			//WARNING THIS COULD MESS UP THE GAME LATER ON SINCE ITS INJECT INTO A RANDOM AREA IN MEMORY, 
			//BUT FOR THE POINT OF THE HOMEWORK ITS THIS AREA
			DWORD myCheat_InstrAddressCreateJump = 0x00430AE5;//Address to create the jump
			DWORD myCheat_InstrAddressRandomAddress = 0x00461383;//Random address to inject code into. 

			char jumpToCheatFunction[7] = {
				'\xE9','\x99','\x08','\x03','\x00',//Create the jump instruction
				'\x90','\x90'//change this address back into test eax, eax cause it changes for whatever reason
				//create the jump to get into the created cheat function
			};

			char injectCheatFunction[37] = { '\x50',//push eax
				'\xA1' ,'\xA8','\xD1','\x50','\x00',//mov eax, [0050D1A8] get doom guy info
				'\x39','\xF8',//cmp eax, edi check if hes getting hit
				'\x74','\x0F',//je chocolate-doom.exe+10D1A8 //skip some instructions
				'\x58',//pop eax
				'\x2D', '\xFF','\x00','\x00','\x00',//sub eax, 000000FF	kill monster with 255 damage
				'\x89', '\x47','\x6C',//mov[edi + 6C], eax
				'\xE9', '\x4F','\xF7','\xFC','\xFF',//jmp chocolate-doom.exe+30AEA return
				'\x90',//nop 
				'\x58',//pop eax regular health shellcode
				'\x29','\xD8',//sub eax, ebx
				'\x89', '\x47','\x6C',//mov[edi + 6C], eax
				'\xE9', '\x43','\xF7','\xFC','\xFF','\x90'//jmp chocolate - doom.exe+30AEA return out of cheat function
			};
			overwriteMemory(myCheat_InstrAddressRandomAddress, injectCheatFunction, sizeof(injectCheatFunction));//create the cheat function first, otherwise it crashes
			injectionCreated = true;//make sure it creates the code first before the jump otherwise will crash as it jumps knowhere
			if (injectionCreated) {
				overwriteMemory(myCheat_InstrAddressCreateJump, jumpToCheatFunction, sizeof(jumpToCheatFunction));//create the jump to the cheat function
			}
		}
		else if (String::Compare(input, "one-shot off", true) == 0) {
			DWORD myCheat_InstrAddressCreateJump = 0x00430AE5;//Real Health part1
			DWORD myCheat_InstrAddressRandomAddress = 0x00461383;//Random address to inject code into.
			char jumpToCheatFunction[7] = {
				'\x29','\xD8', //sub eax, ebx
				'\x89','\x47','\x6C', //mov[edi + 6C], eax
				'\x85','\xC0'//test eax, eax
			};

			//Since the functionCheatInjection was created to be injected into random memory
			//This is reset that memory to how it was originally
			char injectionCheatOriginal[36] = { '\x00',
				'\x00','\x00','\x00','\x00','\x00',
				'\x00','\x00',
				'\x00','\x00',
				'\x00',
				'\x00','\x00','\x00','\x00','\x00',
				'\x00','\x00','\x00',
				'\x00','\x00','\x00','\x00','\x00',
				'\x00',
				'\x00',
				'\x00','\x00',
				'\x00','\x00','\x00',
				'\x00','\x00','\x00','\x00','\x00',
			};

			overwriteMemory(myCheat_InstrAddressRandomAddress, injectionCheatOriginal, sizeof(injectionCheatOriginal));//create the cheat function first, otherwise it crashes
			overwriteMemory(myCheat_InstrAddressCreateJump, jumpToCheatFunction, sizeof(jumpToCheatFunction));//create the jump to the cheat function

		}


		//Task 6 - rapidfire
		if (String::Compare(input, "rapid fire on", true) == 0) {//enable rapid fire
			myCheat_InstrAddress = 0x0043DA09;
			char fastRapidFire[2] = { '\xEB', '\x29' };//convert je to jump for rapid fire
			overwriteMemory(myCheat_InstrAddress, fastRapidFire, sizeof(fastRapidFire));//overwrite value
		}
		else if (String::Compare(input, "rapid fire off", true) == 0) {//disable rapid fire
			myCheat_InstrAddress = 0x0043DA09;
			char fastRapidFire[2] = { '\x74', '\x29' };//convert jump into je
			overwriteMemory(myCheat_InstrAddress, fastRapidFire, sizeof(fastRapidFire));//overwrite ammo value
		}

		

	}

	private: System::Void overwriteMemory(DWORD addressToWrite, char* valueToWrite, int numBytesToWrite) {

        //TODO: comment each line in this function
        unsigned long savedProtection;
        //The address of the starting page of the region of pages whose access protection attributes are to be changed.
        //The size of the region whose access protection attributes are to be changed, in bytes.
        //The memory protection option.A pointer to a variable that receives the previous access protection value of the first page in the specified region of pages. 
        //If this parameter is NULL or does not point to a valid variable, the function fails.
        VirtualProtect((LPVOID)(addressToWrite), numBytesToWrite, PAGE_EXECUTE_READWRITE, &savedProtection);

        //TODO: Insert code to copy values to memory
        //Copies bytes between buffers. 
        //address we are gonna write to, the value we are gonna write (cheat), the size of the cheat
        memcpy((LPVOID)addressToWrite, valueToWrite, numBytesToWrite);

        //Changes the protection on a region of committed pages in the virtual address space of the calling process.
        VirtualProtect((LPVOID)(addressToWrite), numBytesToWrite, savedProtection, NULL);

    }

	};


}
