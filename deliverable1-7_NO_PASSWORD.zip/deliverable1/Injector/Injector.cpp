#include <fstream>
#include <tchar.h>
#include <stdio.h>
#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <string>

int testIfFileExists(char* dllToInject)
{
	std::ifstream dllfile(dllToInject, std::ios::binary);
	if (!dllfile)
	{
		printf("%s does could not be found!", dllToInject);
		exit(-1);
	}

	return 0;
}

int getProcIDByName(char* victimProcessName)
{
	PROCESSENTRY32 pe32 = { sizeof(PROCESSENTRY32) };
	HANDLE hProcSnap;
	int procID = 0;
	while (!procID)
	{
		system("CLS");
		printf("Searching for %s\r\n", victimProcessName);
		printf("Make sure process is running");
		hProcSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

		if (Process32First(hProcSnap, &pe32))
		{
			do
			{
				if (!strcmp(pe32.szExeFile, victimProcessName))
				{
					procID = pe32.th32ProcessID;
					return procID;
				}
			} while (Process32Next(hProcSnap, &pe32));
		}
		Sleep(1000);
	}
	return -1;
}

void forceProcessToLoadDLL(char* dllToInject, int procID)
{
	/*
	* Get process handle by process ID.
	*/
	HANDLE hVictimProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, procID);

	/*
	*TODO: Complete this part of the code!!!!!!!!!
	*  Include thorough comments!
	*/
	if (procID == NULL) {
		printf("Error: the specified process couldn't be found.");
	}

	HMODULE hModule = GetModuleHandle("kernel32.dll");
	FARPROC hProAddress = GetProcAddress(hModule, "LoadLibraryA");
	if (!hProAddress) {
		printf("Error: the LoadLibraryA function was not found inside kernel32.dll");
	}

	void* allocated_memory = VirtualAllocEx(hVictimProcess, NULL, strlen(dllToInject), MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
	if (!allocated_memory) {
		printf("Error: the memory could not be allocated inside the chosen process");
	}

	BOOL hWriteProcess = WriteProcessMemory(hVictimProcess, allocated_memory, dllToInject, strlen(dllToInject), nullptr);
	if (!hWriteProcess) {
		printf("Error: there was no bytes written to the process's address space");
	}

	HANDLE hThread = CreateRemoteThread(hVictimProcess, nullptr, NULL, LPTHREAD_START_ROUTINE(LoadLibraryA), allocated_memory, NULL, nullptr);
	if (!hThread) {
		printf("Error: the remote thread could not be created.");
	}
	else {
		printf("Success: the remote thread was successfully created.");
	}

	/*
	* Close the handle to the process
	*/
	CloseHandle(hVictimProcess);
	getchar();
}


int _tmain(int argc, char* argv[]) {
	if (argc < 3)
	{
		printf("Usage: Injector.exe <pathToDLL> <victimProcessName>\r\n<pathToDLL> is the location where the dll exists (e.g., \"C:\\Users\\Dell Precision\\Documents\\Visual Studio 2010\\Projects\\DLLInject\\Debug\\DLLInject.dll\")\r\n<victimProcessName> is the name of the victim process that we will force to load the dll (e.g., myfile.exe).");
		exit(-1);
	}
	char* pathToDLL = argv[1];
	char* victimProcessName = argv[2];
	int procID = -1;
	testIfFileExists(pathToDLL);

	printf("Identifying ProcessID by name...");
	procID = getProcIDByName(victimProcessName);
	printf("Attempting to load dll into process...");
	forceProcessToLoadDLL(pathToDLL, procID);

	return 0;
}

