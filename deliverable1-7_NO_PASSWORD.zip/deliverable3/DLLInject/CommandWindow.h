#pragma once

#include <Windows.h>
#include <stdio.h>
#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif
namespace DLLInject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/*
	 *TODO: the following initial values do not work! Change these and include comments!
	 * MOVED TO PROCESS INPUT
	 */
	boolean rapidFire;
	/// <summary>
	/// Summary for StatusWindow
	/// </summary>
	public ref class StatusWindow : public System::Windows::Forms::Form
	{
	public:
		StatusWindow(void)
		{
			InitializeComponent();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~StatusWindow()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ submitButton;
	protected:
	private: System::Windows::Forms::TextBox^ inputTextBox;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->submitButton = (gcnew System::Windows::Forms::Button());
			this->inputTextBox = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// submitButton
			// 
			this->submitButton->Location = System::Drawing::Point(118, 95);
			this->submitButton->Name = L"submitButton";
			this->submitButton->Size = System::Drawing::Size(163, 41);
			this->submitButton->TabIndex = 0;
			this->submitButton->Text = L"Submit";
			this->submitButton->UseVisualStyleBackColor = true;
			this->submitButton->Click += gcnew System::EventHandler(this, &StatusWindow::submitButton_Click);
			// 
			// inputTextBox
			// 
			this->inputTextBox->Location = System::Drawing::Point(36, 36);
			this->inputTextBox->Name = L"inputTextBox";
			this->inputTextBox->Size = System::Drawing::Size(337, 20);
			this->inputTextBox->TabIndex = 1;
			this->inputTextBox->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &StatusWindow::inputTextBox_KeyDown);
			// 
			// StatusWindow
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(401, 148);
			this->Controls->Add(this->inputTextBox);
			this->Controls->Add(this->submitButton);
			this->Name = L"StatusWindow";
			this->Text = L"CommandWindow";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void inputTextBox_KeyDown(System::Object^ sender, System::Windows::Forms::KeyEventArgs^ e) {
		if (e->KeyCode == Keys::Enter)
		{
			processInput();
		}

	}

	private: System::Void submitButton_Click(System::Object^ sender, System::EventArgs^ e) {
		processInput();
	}

	private: System::Void processInput() {
		String^ input = inputTextBox->Text;//user input
		inputTextBox->Text = "";

		//Task 2 - Unlimited Ammo
		char cheat_myCheat_Instr[7] = { '\x90', '\x90' ,'\x90', '\x90' ,'\x90' ,'\x90','\x90' };//remove the subtraction
		char original_myCheat_Instr[7] = { '\x29', '\x8C' ,'\x90', '\xA4' ,'\x00' ,'\x00','\x00' };//original code
		int num_myCheat_InstrBytes = sizeof(original_myCheat_Instr);//size of the cheat
		DWORD myCheat_InstrAddress = 0x0043D971;//address of the original 
		if (String::Compare(input, "ammo cheat on", true) == 0)//enable infinite ammo cheat
			overwriteMemory(myCheat_InstrAddress, cheat_myCheat_Instr, num_myCheat_InstrBytes);
		else if (String::Compare(input, "ammo cheat off", true) == 0)//disable infinite ammo cheat
			overwriteMemory(myCheat_InstrAddress, original_myCheat_Instr, num_myCheat_InstrBytes);

		//Task 3 - Set Ammo
		//split the input to obtain the value the user wants to set the ammo
		array<String^>^ SplitInput = input->Split(' ');//ammot set 50
		//puts back ammo + set with space in between
		String^ inputToCheck = SplitInput[0] + " " + SplitInput[1];//used for the input
		if (String::Compare(inputToCheck, "ammo set", true) == 0) {//cheat used to set ammo
			myCheat_InstrAddress = 0x0050D24C;//get ammo address
			char new_cheat[1] = { System::Convert::ToByte(SplitInput[2]) };//convert input into bytes
			overwriteMemory(myCheat_InstrAddress, new_cheat, sizeof(new_cheat));//overwrite ammo value
		}

		

	}

	private: System::Void overwriteMemory(DWORD addressToWrite, char* valueToWrite, int numBytesToWrite) {

        //TODO: comment each line in this function
        unsigned long savedProtection;
        //The address of the starting page of the region of pages whose access protection attributes are to be changed.
        //The size of the region whose access protection attributes are to be changed, in bytes.
        //The memory protection option.A pointer to a variable that receives the previous access protection value of the first page in the specified region of pages. 
        //If this parameter is NULL or does not point to a valid variable, the function fails.
        VirtualProtect((LPVOID)(addressToWrite), numBytesToWrite, PAGE_EXECUTE_READWRITE, &savedProtection);

        //TODO: Insert code to copy values to memory
        //Copies bytes between buffers. 
        //address we are gonna write to, the value we are gonna write (cheat), the size of the cheat
        memcpy((LPVOID)addressToWrite, valueToWrite, numBytesToWrite);

        //Changes the protection on a region of committed pages in the virtual address space of the calling process.
        VirtualProtect((LPVOID)(addressToWrite), numBytesToWrite, savedProtection, NULL);

    }

	};


}
